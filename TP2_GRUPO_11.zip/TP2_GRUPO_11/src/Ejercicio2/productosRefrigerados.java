package Ejercicio2;

public class productosRefrigerados extends Producto {

}
