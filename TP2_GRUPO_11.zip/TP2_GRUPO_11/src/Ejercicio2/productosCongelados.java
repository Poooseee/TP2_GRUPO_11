package Ejercicio2;

public class productosCongelados extends Producto {

}
