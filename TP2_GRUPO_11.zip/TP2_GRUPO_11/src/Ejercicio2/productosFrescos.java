package Ejercicio2;

public class productosFrescos extends Producto {

}
