package Ejercicio3;

public class instalacionDeportiva extends Edificio {

}
