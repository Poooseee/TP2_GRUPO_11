package Ejercicio3;

public class edificioOficinas extends Edificio {
	
}
