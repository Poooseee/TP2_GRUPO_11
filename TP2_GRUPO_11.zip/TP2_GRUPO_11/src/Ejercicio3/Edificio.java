package Ejercicio3;

public class Edificio {
	private int superficieEdificio;
}
