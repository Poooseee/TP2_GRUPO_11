package Ejercicio3;

public class Polideportivo extends instalacionDeportiva {

}
